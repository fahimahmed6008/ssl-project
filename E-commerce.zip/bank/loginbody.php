<?php
$sesuser = $_SESSION["sesuser"];
$sesmail = $_SESSION["sesmail"];
$sespass = $_SESSION["sespass"];
$sesid = $_SESSION["sesid"];
$sesbal = $_SESSION["sesbal"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIUB Bookshop</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-4.0.0-dist/css/bootstrap.min.css" />
    <script src="bootstrap/bootstrap-4.0.0-dist/js/bootstrap.min.js"> </script>
    <link rel="stylesheet" href="stylesheet/style.css" />
</head>

<body>
    <?php require("nav.php")?>
    <br /><br /><br />
    <div class="container">
        <table class="table" style="border: 1px solid rgba(0,0,0,.15);">
            <tbody>
                <tr>
                <th scope="row">1</th>
                    <td>ID</td>
                    <td><?php echo $sesid ?></td>
                </tr>
                <tr>
                    <th scope="row">2</th>
                    <td>Username</td>
                    <td><?php echo $sesuser ?></td>
                </tr>
                <tr>
                    <th scope="row">3</th>
                    <td>Email</td>
                    <td><?php echo $sesmail ?></td>
                </tr>
                <tr>
                    <th scope="row">4</th>
                    <td>Balance</td>
                    <td colspan="2"><?php echo $sesbal ?> tk</td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>
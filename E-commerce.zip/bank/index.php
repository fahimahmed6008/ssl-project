<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIUB Bank</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-4.0.0-dist/css/bootstrap.min.css" />
    <script src="bootstrap/bootstrap-4.0.0-dist/js/bootstrap.min.js"> </script>
    <link rel="stylesheet" href="stylesheet/style.css" />
</head>

<body>
    <?php require("nav.php") ?>

    <div class="container">
        <form class="form-signin" action="login.php" method="POST">
            <div class="text-center mb-4">
                <img class="mb-4" src="images/logo.png" alt="" style="padding:16px;width: 160px">
                <h1 class="h3 mb-3 font-weight-normal">AIUB Bank</h1>
                <h1 class="h6 mb-3 font-weight-normal">ONLINE INTERNET BANKING</h1>
            </div>

            <div class="form-label-group">
                <label for="inputEmail">Email address</label>
                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" name="logmail" required="" autofocus="">
            </div>

            <div class="form-label-group">
                <label for="inputPassword">Password</label>
                <input type="password" id="inputPassword" class="form-control" name="logpass" placeholder="Password" required="">
            </div><br />
            <button class="btn btn-lg btn-primary btn-block" type="submit" name="logsub">Sign in</button>
        </form>
    </div>
</body>

</html>
<?php
session_start();
session_unset();
session_destroy();
echo "<h3 style='color: red'>Logged out!</h3><hr />";
require("index.php");
?>
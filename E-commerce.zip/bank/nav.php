<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
    <h5 class="my-0 mr-md-auto font-weight-normal"><a href="index.php"><img class="mb-4" src="images/logo.png" alt="" style="width: 65px" /></a></h5>
    <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="index.php">Login</a>
        <a class="p-2 text-dark" href="login.php">Dashboard</a>
        <a class="p-2 text-dark" href="#">About</a>
        <a class="p-2 text-dark" href="#">Help</a>
    </nav>
    <?php
        if(!isset($_SESSION["sesuser"])){
            echo "<a class='btn btn-outline-primary' href='signup.php'>Sign up</a>";
        }else{
            echo "<a class='btn btn-outline-primary' href='login.php'>{$_SESSION["sesuser"]}</a>&nbsp;";
            echo "<a class='btn btn-outline-primary' href='logout.php'>Logout</a>";
        }

    ?>
</div>



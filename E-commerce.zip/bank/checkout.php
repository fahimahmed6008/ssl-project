<?php require("var.php") ?>
<?php
if (isset($_POST["clientsub"])) {
    $clientMail = strtolower($_POST["clientMail"]);
    $clientPass = $_POST["clientPass"];

    $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
    $sql = "SELECT * FROM $dbclientstable WHERE email='{$clientMail}' AND pass='{$clientPass}'";
    $result = mysqli_query($conn, $sql);
    $rowNum = mysqli_num_rows($result);

    if ($rowNum == 0) {
        echo "<h3>Purchase Failed</h3>";
        exit;
    } else {
        $bankmail = strtolower($_POST["bankmail"]);
        $bankpass = $_POST["bankpass"];
        $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
        $sql = "SELECT * FROM $dbclientstable WHERE email='{$bankmail}' AND pass='{$bankpass}'";
        $result = mysqli_query($conn, $sql);
        $rowData = mysqli_fetch_assoc($result);
        echo $rowData["balance"];
        $addition = $rowData["balance"] + $_POST["price"];
        $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
        $sql = "SELECT * FROM $dbclientstable WHERE email='{$clientMail}' AND pass='{$clientPass}'";
        $result = mysqli_query($conn, $sql);
        $rowData = mysqli_fetch_assoc($result);
        $substract = $rowData["balance"] - $_POST["price"];
        $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
        $sql = "UPDATE $dbclientstable SET balance=$addition WHERE email='{$bankmail}' AND pass='{$bankpass}'";
        $result = mysqli_query($conn, $sql);
        $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
        $sql = "UPDATE $dbclientstable SET balance=$substract WHERE email='{$clientMail}' AND pass='{$clientPass}'";
        $result = mysqli_query($conn, $sql);

        header("location:http://localhost/ecom/success.php?amount={$_POST["price"]}&pid={$_POST["pid"]}");
    }
}

?>
<?php

if (isset($_POST["price"]) && isset($_POST["id"]) && isset($_POST["bankmail"]) && isset($_POST["bankpass"])) {
    $price = $_POST["price"];
    $id = $_POST["id"];
    $bankmail = strtolower($_POST["bankmail"]);
    $bankpass = $_POST["bankpass"];
} else {
    echo "<h3>Bad request</h3>";
    exit;
}
?>

<?php
$conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
$sql = "SELECT * FROM $dbclientstable WHERE email='{$bankmail}' AND pass='{$bankpass}'";
$result = mysqli_query($conn, $sql);
$rowNum = mysqli_num_rows($result);
if ($rowNum == 0) {
    echo "<h3>Store account's credential is not matching.</h3>";
    exit;
} else {
    echo "Data found";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIUB Bank</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-4.0.0-dist/css/bootstrap.min.css" />
    <script src="bootstrap/bootstrap-4.0.0-dist/js/bootstrap.min.js"> </script>
    <link rel="stylesheet" href="stylesheet/style.css" />
</head>

<body>

    <div class="container p-5 bg-light border rounded-3">
        <h2>Product ID: <?php echo $id; ?></h2>
        <h2>Price: <?php echo $price; ?></h2>
    </div>

    <!-- http://localhost/ecom/success.php?amount={$_POST["price"]}&pid={$_POST["pid"]} -->

    <div style="width: 85%;max-width: 760px; margin: 80px auto 20px; border: 1px solid rgba(5,5,5,.15); padding: 20px 40px">
        <form action="" method="POST">
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">AIUB Bank Registered Email:</label>
                <input type="email" name="clientMail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required />
                <input type="hidden" name="price" value="<?php echo $price; ?>" />
                <input type="hidden" name="bankmail" value="<?php echo $bankmail; ?>" />
                <input type="hidden" name="bankpass" value="<?php echo $bankpass; ?>" />
                <input type="hidden" name="pid" value="<?php echo $id; ?>" />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" name="clientPass" class="form-control" id="exampleInputPassword1" requried />
            </div>
            <button type="submit" name="clientsub" class="btn btn-primary">Confirm Purchase</button>
        </form>
    </div>
</body>

</html>
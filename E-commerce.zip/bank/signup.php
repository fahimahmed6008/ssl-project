<?php
require("var.php");
if(isset($_POST["submit"])){
    $username = $_POST["username"];
    $userpass = $_POST["userpass"];
    $usermail = strtolower($_POST["usermail"]);

    $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
    $sql = "SELECT * FROM $dbclientstable WHERE email='{$usermail}'";
    $result = mysqli_query($conn, $sql);
    $rowNum = mysqli_num_rows($result);

    if($rowNum != 0){
        echo "<h2>This E-mail is already exists!</h2><br />";
    }else{
        $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
        $sql = "INSERT INTO $dbclientstable (email, pass, username) VALUES ('{$usermail}','{$userpass}','{$username}')";
        $result = mysqli_query($conn, $sql);
        echo "<h2>Registration Successful!</h2><br />";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIUB Bank</title>
</head>

<body>
    <?php require("nav.php") ?>

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AIUB Bookshop</title>
        <link rel="stylesheet" href="bootstrap/bootstrap-4.0.0-dist/css/bootstrap.min.css" />
        <script src="bootstrap/bootstrap-4.0.0-dist/js/bootstrap.min.js"> </script>
        <link rel="stylesheet" href="stylesheet/style.css" />
    </head>

    <body>

        <div class="container">
            <form class="form-signin" action="" method="POST">
                <div class="text-center mb-4">
                    <img class="mb-4" src="images/logo.png" alt="" style="padding:16px;width: 160px">
                    <h1 class="h3 mb-3 font-weight-normal">AIUB Bank</h1>
                    <h1 class="h6 mb-3 font-weight-normal">ONLINE INTERNET BANKING</h1>
                </div>
                
                <div class="form-label-group">
                    <label for="inputEmail">Username</label>
                    <input type="text" name="username" id="inputEmail" class="form-control" placeholder="Username" required="" autofocus="">
                </div>

                <div class="form-label-group">
                    <label for="inputEmail">Email address</label>
                    <input type="email" name="usermail" id="inputEmail" class="form-control" placeholder="Email address" required="" autofocus="">
                </div>

                <div class="form-label-group">
                    <label for="inputPassword">Password</label>
                    <input type="password" name="userpass" id="inputPassword" class="form-control" placeholder="Password" required="">
                </div><br />
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit">Sign up</button>
            </form>
        </div>
    </body>

</html>
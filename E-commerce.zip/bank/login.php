<?php require("var.php") ?>
<?php
?>
<?php
if (isset($_POST["logsub"])) {
    $logmail = strtolower($_POST["logmail"]);
    $logpass = $_POST["logpass"];
    $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
    $sql = "SELECT * FROM $dbclientstable WHERE email='{$logmail}' AND pass='{$logpass}'";
    $result = mysqli_query($conn, $sql);
    $rowNum = mysqli_num_rows($result);

    if ($rowNum == 0) {
        echo "<h3 style='color: red;'>Incorrect username or password!</h3> <hr />";
        require("index.php");
    } else {
        session_start();
        $rowData = mysqli_fetch_assoc($result);
        $_SESSION["sesuser"] = $rowData["username"];
        $_SESSION["sesmail"] = $rowData["email"];
        $_SESSION["sespass"] = $rowData["pass"];
        $_SESSION["sesid"] = $rowData["ID"];
        $_SESSION["sesbal"] = $rowData["balance"];
        header("location:login.php");
    }
} else {
    session_start();
    if (isset($_SESSION["sesuser"])) {
        require("loginbody.php");
    } else {
        header("location:index.php");
    }
}

?>
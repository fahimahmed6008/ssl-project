<?php
$dbhost = "localhost";
$dbpass = "";
$dbroot = "root";
$dbname = "bank";
$dbclientstable = "clients";
?>
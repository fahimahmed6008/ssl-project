<?php
$PopConn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
$PopSql = "SELECT * FROM $dbitemtable ORDER BY pid DESC LIMIT 4";
$Popres = mysqli_query($PopConn, $PopSql);
$PopRows = mysqli_num_rows($Popres);
?>
<div class="container" style="margin: auto; font-size: 2rem;">
    <h1>POPULAR NOW</h1>
</div>
<div class="popHolder">
    <?php
    if ($PopRows == 0) {
    } else {
        while ($PopData = mysqli_fetch_assoc($Popres)) {

    ?>
            <a href="product.php?id=<?php echo "{$PopData["PID"]}"; ?>" class="items-parent">
                <div class="items-holder">
                    <div class="item-image">
                        <img src="product_img/<?php echo $PopData["imageName"]; ?>" />
                    </div>
                    <div class="item-name">
                        <p class="card-text"><?php echo $PopData["Name"]; ?></p>
                    </div>
                </div>
            </a>
    <?php
        }
    }
    ?>
</div>
<br /><br /><br />
<div class="item-footer">
    These whole project is made as an assignment. All rigths reserved @2022
</div>
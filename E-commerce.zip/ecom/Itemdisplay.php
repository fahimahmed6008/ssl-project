<div class="product-holder">
    <div class="img_container">
        <img src="product_img/<?php echo $itemData["imageName"]; ?>" />
    </div>
    <div class="details_container">
        <p><?php echo "Product ID: {$itemData["PID"]} <br />"; ?></p>
        <p><?php echo "Name: {$itemData["Name"]} <br />"; ?></p>
        <p><?php echo "Price: {$itemData["Price"]} <br />"; ?></p>
        <p style="margin-bottom: 40px;"><?php echo "Description: {$itemData["Description"]} <br />"; ?></p>
        <p>
            <?php
                if(isset($_SESSION["user-name"])){
                    echo "<a href='checkout.php?price={$itemData["Price"]}&id={$itemData["PID"]}&cid={$_SESSION["user-id"]}'><button>Buy Now</button></a>";
                }else{
                    echo "<a href='#'><button onclick='alert(\"You must login first!\")'>Buy Now</button></a>";
                }
            ?>
        
        <form action="carts.php" method="GET" class="cart_hide">
            <button type="submit" name="submit" value="<?php echo $itemData["PID"]; ?>">Add to cart</button>
        </form>
        <form action="carts.php" method="GET" class="cart_hide2">
            <button type="submit" name="ID" value="<?php if(isset($rowData2["ID"]))echo $rowData2["ID"]; ?>">Remove</button>
        </form>
        </p>
    </div>
</div>
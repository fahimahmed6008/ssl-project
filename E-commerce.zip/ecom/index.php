<?php include"var.php" ?>

<?php
    session_start();
    if(isset($_POST["sign-mail"]) && isset($_POST["sign-pass"])){

        $logMail = strtolower($_POST["sign-mail"]);
        $logPass = strtolower($_POST["sign-pass"]);
        $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
        $sql = "SELECT * FROM $dbusertable WHERE email='$logMail' AND password='$logPass'";
        $result = mysqli_query($conn, $sql);
        $userCheck = mysqli_num_rows($result);
        if($userCheck == 1){
            $row = mysqli_fetch_assoc($result);
            $_SESSION["user-id"] = $row["CID"];
            $_SESSION["user-mail"] = $row["email"];
            $_SESSION["user-pass"] = $row["password"];
            $_SESSION["user-name"] = $row["username"];
        }else{
            echo "<h3>Wrong Email or Password</h3><hr />";
        }
        
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIUB Bookshop</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-5.2.2-dist/css/bootstrap.min.css" />
    <script src="bootstrap/bootstrap-5.2.2-dist/js/bootstrap.min.js"> </script>
    <script src="scripts/nav.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="stylesheet/style.css" />
</head>

<body>
    <?php require("nav.php") ?>
    <?php require("hero.php") ?>
</body>

</html>
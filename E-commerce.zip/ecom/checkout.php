<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    print_r($_REQUEST);
    $bankmail = "store@mail.edu";
    $bankpass = "Test1234";
    ?>
    <button class="btn">Btn</button>
    <form id="myForm" action="http://localhost/bank/checkout.php" method="POST">
        <input type="hidden" name="price" value="<?php echo $_REQUEST["price"]; ?>" />
        <input type="hidden" name="id" value="<?php echo $_REQUEST["id"]; ?>" />
        <input type="hidden" name="bankmail" value="<?php echo $bankmail; ?>" />
        <input type="hidden" name="bankpass" value="<?php echo $bankpass; ?>" />
    </form>

    <script>
        window.onload = function() {
            document.getElementById("myForm").submit();
        }
    </script>
</body>

</html>
<?php
$conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
$sql = "SELECT * FROM $dbcarttable WHERE CID={$_SESSION["user-id"]}";
$res = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $rowNum = mysqli_num_rows($res);
    if ($rowNum == 0) {
        
    ?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>AIUB Bookshop</title>
            <link rel="stylesheet" href="bootstrap/bootstrap-5.2.2-dist/css/bootstrap.min.css" />
            <script src="bootstrap/bootstrap-5.2.2-dist/js/bootstrap.min.js"> </script>
            <script src="scripts/nav.js"></script>
            <script src="https://cdn.tailwindcss.com"></script>
            <link rel="stylesheet" href="stylesheet/style.css" />
        </head>

        <body>
            <?php //require("nav.php") ?><br /><br /><br />
            <hr/><h3>Cart is empty</h3><hr/>
            <?php require("gallery.php") ?>

        </body>

        </html>
    <?php
    } else { ?>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>AIUB Bookshop</title>
            <link rel="stylesheet" href="bootstrap/bootstrap-5.2.2-dist/css/bootstrap.min.css" />
            <script src="bootstrap/bootstrap-5.2.2-dist/js/bootstrap.min.js"> </script>
            <script src="scripts/nav.js"></script>
            <script src="https://cdn.tailwindcss.com"></script>
            <link rel="stylesheet" href="stylesheet/style.css" />
            <style>
                .cart_hide {
                    display: none !important;
                }
            </style>
        </head>

        <body>
            <?php
            while ($rowData2 = mysqli_fetch_assoc($res)) {
                $pidNo = $rowData2["PID"];
                $connItem = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
                $sqlItem = "SELECT * FROM $dbitemtable WHERE PID=$pidNo";
                $resItem = mysqli_query($connItem, $sqlItem);
                while ($itemData = mysqli_fetch_assoc($resItem)) { ?>

                    <?php require("Itemdisplay.php"); ?>

            <?php }
            } ?>
            <!-- </body>

        </html> -->

        <?php
    }
        ?>
        </body>

        </html>
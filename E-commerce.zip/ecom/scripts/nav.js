window.addEventListener("load", ()=>{
    const loginBtn = document.querySelector(".login-btn");
    const signupBtn = document.querySelector(".signup-btn");
    const loginForm = document.querySelector(".login-form");
    const signupForm = document.querySelector(".signup-form");
    const grayColor = document.querySelector(".gray-color");

    const cross = document.querySelectorAll(".cross");
    console.log(loginBtn);
    console.log(signupBtn);

    loginBtn.addEventListener("click", (e)=>{
        loginForm.classList.toggle("item-hide");
        grayColor.classList.toggle("item-hide");
    });

    signupBtn.addEventListener("click", (e)=>{
        signupForm.classList.toggle("item-hide");
        grayColor.classList.toggle("item-hide");
    });
    
    cross.forEach(item=>{
        item.addEventListener("click", (e)=>{
            const item = e.target.parentNode;
            item.classList.toggle("item-hide");
            grayColor.classList.toggle("item-hide");
        })
    })

    grayColor.addEventListener("click", (e)=>{
        loginForm.classList.add("item-hide");
        signupForm.classList.add("item-hide");
        e.target.classList.add("item-hide");
    });

})

<?php require("var.php") ?>
<div class="container col-xxl-8 px-4 py-5">
    <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
        <div class="col-10 col-sm-8 col-lg-6">
            <img src="images/library.jpg" class="d-block mx-lg-auto img-fluid" alt="Bootstrap Themes" width="700" height="500" loading="lazy">
        </div>
        <div class="col-lg-6">
            <h1 class="display-5 fw-bold lh-1 mb-3">AIUB Bookshop. Largest online book portal in Bangladesh.</h1>
            <p class="lead">The Library has grown steadily and expanded its services and holdings by leaps and bounds to live-up to the expectations of its immediate patrons. The book stock is arranged in a classified sequence based on the Dewey Decimal System (DDC), and the great majority of volumes in the Library are on open shelves, available for borrowing.</p>
            <br /><br />
            <div class="d-grid gap-2 d-md-flex justify-content-md-start">
                <button type="button" class="btn btn-outline-secondary btn-lg px-4">Read More.</button>
                <button type="button" class="btn btn-outline-secondary btn-lg px-4">Download</button>
            </div>
        </div>
    </div>
</div>


<!-- Gallery -->
<?php require("gallery.php") ?>




<?php include"var.php" ?>

<?php
echo "<br />";

if(isset($_POST["log-name"]) && isset($_POST["log-mail"]) && isset($_POST["log-pass"])){
    $logName = $_POST["log-name"];
    $logMail = strtolower($_POST["log-mail"]);
    $logPass = $_POST["log-pass"];
    $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
    $sql = "SELECT * FROM $dbusertable WHERE email='$logMail'";
    $result = mysqli_query($conn, $sql);
    $userCheck = mysqli_num_rows($result);
    if($userCheck == 0){
        $sql = "INSERT INTO $dbusertable (username, password, email) VALUES ('$logName', '$logPass', '$logMail')";
        $result = mysqli_query($conn, $sql);
        echo "<h3>Registration Successful! </h3><hr />";
    }else{
        echo "<h3>User already exists! </h3><hr />";
    }
}else{
    
}


?>

<?php require("index.php"); ?>
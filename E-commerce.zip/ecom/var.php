<?php
$dbhost = "localhost";
$dbpass = "";
$dbroot = "root";
$dbname = "ecom";
$dbusertable = "username";
$dbcarttable = "carts";
$dbitemtable = "items";
$dbstorename = "store";
?>
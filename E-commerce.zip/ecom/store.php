<?php require("var.php") ?>
<?php
session_start();
if (isset($_SESSION["user-id"])) {
    $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
    $sql = "SELECT * FROM $dbstorename WHERE cid={$_SESSION["user-id"]}";
    $result = mysqli_query($conn, $sql);

    $resultDataNum = mysqli_num_rows($result);

    if ($resultDataNum == 0) {
        echo "<h3>My Store is empty</h3>";
    } else { ?>

        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>AIUB Bookshop</title>
            <link rel="stylesheet" href="bootstrap/bootstrap-5.2.2-dist/css/bootstrap.min.css" />
            <script src="bootstrap/bootstrap-5.2.2-dist/js/bootstrap.min.js"> </script>
            <script src="scripts/nav.js"></script>
            <script src="https://cdn.tailwindcss.com"></script>
            <link rel="stylesheet" href="stylesheet/style.css" />
        </head>

        <body>
            <?php require("nav.php") ?>
            <h2 style="font-size: 2rem;padding: 25px;background-color: rgb(245,245,245)">Your items: </h2>
            <div class="all-item">

            <?php
            while ($pidData = mysqli_fetch_assoc($result)) {
                $pidNo = $pidData["PID"];
                $pconn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
                $psql = "SELECT * FROM $dbitemtable WHERE PID=$pidNo";
                $presult = mysqli_query($pconn, $psql);
                while ($pidItemData = mysqli_fetch_assoc($presult)) {
                    // print_r($pidItemData);
                    // echo "<br />"; ?>
                    <div class="pid-info-holder">
                        <div class="pid-img-holder">
                            <img src="product_img/<?php echo $pidItemData["imageName"] ?>" />
                        </div>
                        <div class="pid-detail-holder">
                            Product ID: <?php echo $pidItemData["PID"] ?><br />
                            Product Name: <?php echo $pidItemData["Name"] ?>
                            <br />
                            Paid: Success
                        </div>
                    </div>


    <?php
                }
            }

        }
        
    } else {
        echo "<h3>Invalid request!</h3>";
        echo "<h3>Try logging in again!</h3> <br />";
    }
    ?>

</div></body></html>
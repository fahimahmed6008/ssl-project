<div class="nav-container">
    <ul class="nav_options">
        <a href="index.php">
            <li><img src="images/logo.png" /></li>
        </a>
        <a href="index.php">
            <li>Home</li>
        </a>
        <a href="Allproduct.php">
            <li>Products</li>
        </a>
        <a href="#">
            <li>About</li>
        </a>
        <a href="#">
            <li>Help</li>
        </a>
        <a href="#">
            <li class="login-btn">
                <?php
                if (isset($_SESSION["user-name"])) {
                    echo $_SESSION["user-name"];
                } else {
                    echo "Login";
                }
                ?>
            </li>
        </a>

        <?php
        if (isset($_SESSION["user-name"])) {
            echo "<a href='store.php'><li>My Store</li></a>";
            echo "<a href='logout.php'><li class='signup-btn'>Logout</li></a>";
            echo "<a href='carts.php'><li><img src='images/bag-fill.svg' width='24px' /></li></a>";
        } else {
            echo "<a href='#'><li class='signup-btn'>Signup</li></a>";
            echo "<a href='#'><li class=''></li></a>";
            echo "<a href='#'><li class=''></li></a>";
        }
        ?>
        
    </ul>
</div>
<div class="gray-color item-hide"></div>

<!-- LOGIN -->
<form class="container-md add-pos item-hide login-form" action="index.php" method="POST">
    <div class="cross">X</div>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Email address</label>
        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="sign-mail" required>
        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" id="exampleInputPassword1" name="sign-pass" required>
    </div>
    <button type="submit" class="btn btn-outline-primary">Submit</button>
</form>


<!-- REGISTRATION -->
<form class="container-md add-pos item-hide signup-form" action="signup.php" method="POST">
    <div class="cross">X</div>
    <h2>Fill these up for Registration</h2>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Username</label>
        <input type="text" class="form-control" aria-describedby="emailHelp" name="log-name" required>
        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
    </div>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Email address</label>
        <input type="email" class="form-control" aria-describedby="emailHelp" name="log-mail" required>
        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" name="log-pass" required>
    </div>
    <button type="submit" class="btn btn-outline-primary">Submit</button>
</form>
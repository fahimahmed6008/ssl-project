<?php
session_start();
require("var.php");

$pid = $_GET["pid"];
$amount = $_GET["amount"];
echo "<h3>Payment Succesful!</h3>";
echo "<h3>Status: VALID</h3>";
echo "<h3>Product ID: $pid</h3>";
echo "<h3>Price: $amount</h3>";
echo "<h2>You can find your product on <a href='index.php'>My Store</a></h2>";
if (isset($_SESSION["user-id"])) {
    $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
    $sql = "INSERT INTO $dbstorename (PID, CID) VALUES ('$pid', {$_SESSION["user-id"]})";
    mysqli_query($conn, $sql);
} else {
    echo "<h2>Unable to save file on Store.</h2>";
}

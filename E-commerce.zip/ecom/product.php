<?php
    session_start();
?>

<?php require("var.php") ?>

<?php
    if(isset($_GET["id"])){
        $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
        $sql = "SELECT * from $dbitemtable WHERE PID={$_GET["id"]}";

        $reuslt = mysqli_query($conn, $sql);
        $row = mysqli_num_rows($reuslt);
        $itemData = mysqli_fetch_assoc($reuslt);
        
        // echo "Name: {$data["Name"]} <br />";
        // echo "Description: {$data["Description"]} <br />";
        // echo "Price: {$data["Price"]} <br />";
        // echo "imageName: {$data["imageName"]} <br />";

    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-5.2.2-dist/css/bootstrap.min.css" />
    <script src="bootstrap/bootstrap-5.2.2-dist/js/bootstrap.min.js"> </script>
    <script src="scripts/nav.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="stylesheet/style.css" />
    <style>
        .cart_hide2{
            display: none;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <?php require("nav.php") ?>
    <!-- ITEM DATA -->
    <?php require("Itemdisplay.php"); ?>
    <!-- Gallery -->
    <?php require("gallery.php") ?>
</body>
</html>
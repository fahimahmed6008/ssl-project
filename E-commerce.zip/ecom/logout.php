<?php
session_start();
?>

<!DOCTYPE html>
<html>
<body>

<?php
session_unset();
session_destroy();
?>
<h3> Logged Out! </h3><hr />
    <?php require("index.php")?>
</body>
</html>

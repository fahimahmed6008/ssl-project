<?php
session_start();
require("var.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIUB Bookshop</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-5.2.2-dist/css/bootstrap.min.css" />
    <script src="bootstrap/bootstrap-5.2.2-dist/js/bootstrap.min.js"> </script>
    <script src="scripts/nav.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="stylesheet/style.css" />
</head>

<body>
    <?php require("nav.php") ?>
    <?php
    $PopConn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
    $PopSql = "SELECT * FROM $dbitemtable ORDER BY pid DESC";
    $Popres = mysqli_query($PopConn, $PopSql);
    $PopRows = mysqli_num_rows($Popres);
    ?>
    <div class="container" style="margin: auto; font-size: 2rem;">
        <h1>POPULAR NOW</h1>
    </div>
    <div class="popHolder">
        <?php
        if ($PopRows == 0) {
        } else {
            while ($PopData = mysqli_fetch_assoc($Popres)) {

        ?>
                <a href="product.php?id=<?php echo "{$PopData["PID"]}"; ?>" class="items-parent">
                    <div class="items-holder">
                        <div class="item-image">
                            <img src="product_img/<?php echo $PopData["imageName"]; ?>" />
                        </div>
                        <div class="item-name">
                            <p class="card-text"><?php echo $PopData["Name"]; ?></p>
                        </div>
                    </div>
                </a>
        <?php
            }
        }
        ?>
    </div>
    <br /><br /><br />
    <div class="item-footer">
        These whole project is made as an assignment. All rigths reserved @2022
    </div>
</body>

</html>
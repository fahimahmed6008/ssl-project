<?php require("var.php") ?>
<?php
session_start();
if (isset($_GET["ID"])) {
    $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
    $sql = "DELETE FROM $dbcarttable WHERE id = {$_GET["ID"]}";
    $reuslt = mysqli_query($conn, $sql);
}



if (isset($_SESSION["user-name"])) {
    if (isset($_GET["submit"])) {
        $userID = intval($_SESSION["user-id"]);
        $userSUB = intval($_GET["submit"]);
        $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
        $sql = "INSERT INTO $dbcarttable (CID, PID) VALUES ($userID, $userSUB)";
        $reuslt = mysqli_query($conn, $sql);

        echo "<h3>Product Added to cart sucessfully.</h3><hr />";
        require("nav.php");
        require("cartItems.php");
    } else {
        require("nav.php");
        require("cartItems.php");
        
        
    }
} else {
    echo "<h3>Sign in required!</h3><hr />";
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AIUB Bookshop</title>
        <link rel="stylesheet" href="bootstrap/bootstrap-5.2.2-dist/css/bootstrap.min.css" />
        <script src="bootstrap/bootstrap-5.2.2-dist/js/bootstrap.min.js"> </script>
        <script src="scripts/nav.js"></script>
        <script src="https://cdn.tailwindcss.com"></script>
        <link rel="stylesheet" href="stylesheet/style.css" />
    </head>

    <body>
        <?php require("nav.php") ?><br /><br /><br />
        <?php require("gallery.php") ?>
    </body>

    </html>

<?php
}
?>
Mail: bookshopaiub@gmail.com
Password: #Test1234
Store ID: citri6365674f43035
Store Password (API/Secret Key): citri6365674f43035@ssl

Account Information
User Login Id	MahbubHasan
User Name	Bn Limon
Account Type	merchant
Email	bookshopaiub@gmail.com
Account Role	Merchant Admin
Store Information
Number of Stores	1
Company Information
Email	bookshopaiub@gmail.com
Mobile	+8801769420420
Address	Bashundhara, Dhaka



Merchant Panel URL: https://sandbox.sslcommerz.com/manage/ (Credential as you inputted in the time of registration)


 
Store name: testcitrivsz2
Registered URL: http://localhost
Session API to generate transaction: https://sandbox.sslcommerz.com/gwprocess/v3/api.php
Validation API: https://sandbox.sslcommerz.com/validator/api/validationserverAPI.php?wsdl
Validation API (Web Service) name: https://sandbox.sslcommerz.com/validator/api/validationserverAPI.php
 
You may check our plugins available for multiple carts and libraries: https://github.com/sslcommerz
<?php require("var.php")?>

<?php
if(isset($_POST["item-name"]) && isset($_POST["item-price"])){
    $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
    $sql = "INSERT INTO $dbitemtable (Name, Description, Price) VALUES ('{$_POST["item-name"]}', '{$_POST["item-des"]}', {$_POST["item-price"]})";
    if(mysqli_query($conn, $sql)){
        $getLastID = mysqli_insert_id($conn);
        $filename =  $getLastID . "." . explode("/", $_FILES["item-file"]["type"])[1];
        
        $sql = "UPDATE $dbitemtable SET imageName = '{$filename}' WHERE PID = $getLastID";
        mysqli_query($conn, $sql);
        move_uploaded_file($_FILES["item-file"]["tmp_name"], "product_img/$filename");
        echo "<h3>Item uploaded</h3><hr />";
    }else{
        echo "<h3>Something wents wrong</h3><hr />";
    }
}else{
    // echo "Bad request";
}
?>


<?php
    session_start();
    if(isset($_POST["admin-mail"]) && isset($_POST["admin-pass"])){
        if($_POST["admin-mail"] == "rootaccess@mail.co" && $_POST["admin-pass"] == "Test1234"){
            echo "Admin success!";
            $_SESSION["adminMail"] = $_POST["admin-mail"];
            $_SESSION["adminPass"] = $_POST["admin-pass"];
            // $conn = mysqli_connect($dbhost, $dbroot, $dbpass, $dbname);
            // $sql = "";
            // $result = mysqli_query($conn, $sql);

        }else{
            echo "Invalid Authentication.";
        }
        
    }
?>



<?php

if(isset($_SESSION["adminMail"]) && isset($_SESSION["adminPass"])){

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Items</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-5.2.2-dist/css/bootstrap.min.css" />
    <script src="bootstrap/bootstrap-5.2.2-dist/js/bootstrap.min.js"> </script>
</head>

<body>
    <br />

    <a href="logout.php">
        <div style="background-color: orangered;color: white;padding: 10px 240px;margin: 25px;font-weight:bold;font-size:2rem;text-align: center;">Logout</div>
    </a>
    <br /><br /><br /><br />
    <form class="container" action="" method="POST" enctype="multipart/form-data">
        <h1 class="h3 mb-3 fw-normal">Please sign in</h1>

        <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="name@example.com" name="item-name" required>
            <label for="floatingInput">Item name</label>
        </div><br />
        <div class="form-floating">
            <input type="number" class="form-control" id="floatingPassword" placeholder="Password" name="item-price" required>
            <label for="floatingPassword">Item price</label>
        </div>
        <div class="form-floating"><br />
            <p>Item Image:</p>
            <input type="file" name="item-file" accept="image/*" required>
            
        </div>
        <br />
        <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="name@example.com" name="item-des" style="height: 300px;" required>
            <label for="floatingInput">Item Description</label>
        </div><br />
        <button class="w-100 btn btn-lg btn-primary" type="submit">Upload</button>
    </form>
</body>

</html>

<?php 
}
?>